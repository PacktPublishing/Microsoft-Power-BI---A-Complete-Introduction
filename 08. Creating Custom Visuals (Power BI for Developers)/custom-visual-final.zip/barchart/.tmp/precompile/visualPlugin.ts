module powerbi.visuals.plugins {
    export var barchart0DF8AB49A5884B8B9F965E79780EB4AE = {
        name: 'barchart0DF8AB49A5884B8B9F965E79780EB4AE',
        displayName: 'barchart',
        class: 'Visual',
        version: '1.0.0',
        apiVersion: '1.6.0',
        create: (options: extensibility.visual.VisualConstructorOptions) => new powerbi.extensibility.visual.barchart0DF8AB49A5884B8B9F965E79780EB4AE.Visual(options),
        custom: true
    };
}
